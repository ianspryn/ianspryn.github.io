    $('img').ready(function () {

        $('body').hide().fadeIn(1500);
    });
//div#fade-in
/*
        $('body').css('background-image','url(https://lh3.googleusercontent.com/SsUEqWF4cua2t0vU-_Te2HuSzW5zuupN0rOoQPvMngYX=w2400-h1200)');
        */

